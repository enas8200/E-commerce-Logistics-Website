// THEME TOGGLE
function toggleTheme() {
    const body = document.getElementById('body');
    const themeToggle = document.querySelector('.theme-toggle i');
    
    body.classList.toggle('dark-mode');
    
    if (body.classList.contains('dark-mode')) {
        themeToggle.classList.remove('fa-moon');
        themeToggle.classList.add('fa-sun');
        localStorage.setItem('theme', 'dark');
    } else {
        themeToggle.classList.remove('fa-sun');
        themeToggle.classList.add('fa-moon');
        localStorage.setItem('theme', 'light');
    }
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        const body = document.getElementById('body');
        if (body) {
            body.classList.add('dark-mode');
            const themeToggle = document.querySelector('.theme-toggle i');
            if (themeToggle) {
                themeToggle.classList.remove('fa-moon');
                themeToggle.classList.add('fa-sun');
            }
        }
    }
}

// NAVBAR SCROLL EFFECT
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Load theme on page load
document.addEventListener('DOMContentLoaded', loadTheme);

// TRACKING FUNCTION
function trackShipment(){

    let trackingNumber =
    document.getElementById("trackingInput").value;

    if(trackingNumber === ""){
        alert("Please enter a tracking number.");
    }

    else{

        let statuses = [
            "Shipment Received",
            "In Transit",
            "Arrived at Warehouse",
            "Out for Delivery",
            "Delivered Successfully"
        ];

        let randomStatus =
        statuses[Math.floor(Math.random() * statuses.length)];

        alert(
        "Tracking Number: " +
        trackingNumber +
        "\n\nStatus: " +
        randomStatus
        );
    }
}

// FORM VALIDATION
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validateForm(name, email, phone) {
    if (name.trim() === "") {
        alert("Name is required.");
        return false;
    }
    if (!validateEmail(email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    if (phone.trim() === "") {
        alert("Phone number is required.");
        return false;
    }
    return true;
}

// SMOOTH SCROLL
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});
